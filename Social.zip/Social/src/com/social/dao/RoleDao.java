package com.social.dao;

import com.social.beans.Role;
import com.social.beans.Roles;
import com.social.beans.Users;
import com.social.connection.DBCon;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class RoleDao {
    DBCon dbCon = new DBCon();
    Connection jdbcConnection;

    private Connection start(){
        jdbcConnection = dbCon.conectDB();
        return jdbcConnection;
    }
    private void Dbclose() throws SQLException {
        dbCon.conectDB().close();
    }

    public boolean addRole(Roles users) throws SQLException {
        start();
        String sql = "INSERT INTO role_based_user (rolename,username) VALUES (?,?)";
        PreparedStatement statement = jdbcConnection.prepareStatement(sql);
        statement.setString(1,users.getRoleName());
        statement.setString(2,users.getUsername());
        boolean rowInserted = statement.executeUpdate() > 0;
        statement.close();
        return rowInserted;
    }

    public List<Role> listAllRoles() throws SQLException {
        List<Role> listRoles = new ArrayList<>();
        System.out.println("Connection: " +jdbcConnection + " is connected");
        start();
        String sql = "SELECT * FROM role";
        Statement statement = jdbcConnection.createStatement();
        ResultSet resultSet = statement.executeQuery(sql);

        while (resultSet.next()) {
            int id = resultSet.getInt("rolid");
            String rolename = resultSet.getString("rolename");
            Role role = new Role(id,rolename);
            listRoles.add(role);
        }
        System.out.println(listRoles.size());
        resultSet.close();
        statement.close();
        return listRoles;

    }

    public boolean deleteUser(int id) throws SQLException {
        start();
        String sql = "DELETE FROM user where id = ?";
        PreparedStatement statement = jdbcConnection.prepareStatement(sql);
        statement.setInt(1, id);
        boolean rowDeleted = statement.executeUpdate() > 0;
        statement.close();
        return rowDeleted;
    }

//    public boolean updateUser(Users user) throws SQLException {
//        start();
//        String sql = "UPDATE user SET username = ?, firstname = ?, lastname = ?,dateofbirth = ?, email = ?, gender = ?," +
//                "pro_pic_path = ?, ";
//        sql += " WHERE id = ?";
//
//        PreparedStatement statement = jdbcConnection.prepareStatement(sql);
//        statement.setString(1, user.getUsername());
//        statement.setString(2, user.getFirstName());
//        statement.setString(3, user.getLastName());
//        statement.setString(4, user.getBirthDay());
//        statement.setString(5, user.getEmail());
//        statement.setString(6, user.getGender());
//        statement.setString(7, user.getImagePath());
//
//        boolean rowUpdated = statement.executeUpdate() > 0;
//        statement.close();
//
//        return rowUpdated;
//    }

    public Roles  getRole(String username) throws SQLException {
        start();
        Roles role = null;
        String sql = "Select * from role_based_user where username = ?";
        PreparedStatement statement = jdbcConnection.prepareStatement(sql);
        statement.setString(1, username);
        ResultSet resultSet = statement.executeQuery();
        if (resultSet.next()) {
            String rolename = resultSet.getString("rolename");

            role = new Roles(rolename);

        }

        resultSet.close();
        statement.close();

        return role;


    }

    public List<Users> getRoleBasedUsers() throws SQLException {
        start();
        List<Users> listUsers = new ArrayList<>();
        String sql = "SELECT user.id,user.username,firstname,lastname,dateofbirth,email,gender,pro_pic_path,rolename,password from user " +
                "join role_based_user on user.username=role_based_user.username";
        Statement statement = jdbcConnection.createStatement();
        ResultSet resultSet = statement.executeQuery(sql);
        while (resultSet.next()) {
            String rolename = resultSet.getString("rolename");
            int id = resultSet.getInt("id");
            String username = resultSet.getString("username");
            String firstname = resultSet.getString("firstname");
            String lastname = resultSet.getString("lastname");
            String dateofbirth = resultSet.getString("dateofbirth");
            String email = resultSet.getString("email");
            String gender = resultSet.getString("gender");
            String proPicPath = resultSet.getString("pro_pic_path");
            String password = resultSet.getString("password");
            Users users = new Users(id,username,firstname,lastname,dateofbirth,email,gender,proPicPath,rolename,password);
            listUsers.add(users);
        }
        resultSet.close();
        statement.close();
        return listUsers;
    }
}
