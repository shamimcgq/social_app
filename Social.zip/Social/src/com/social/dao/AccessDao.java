package com.social.dao;

import com.social.beans.Access;
import com.social.connection.DBCon;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class AccessDao {
    DBCon dbCon = new DBCon();
    Connection jdbcConnection;

    private Connection start(){
        jdbcConnection = dbCon.conectDB();
        return jdbcConnection;
    }
    private void Dbclose() throws SQLException {
        dbCon.conectDB().close();
    }

//    public boolean addRole(Roles users) throws SQLException {
//        start();
//        String sql = "INSERT INTO role_based_user (rolename,username) VALUES (?,?)";
//        PreparedStatement statement = jdbcConnection.prepareStatement(sql);
//        statement.setString(1,users.getRoleName());
//        statement.setString(2,users.getUsername());
//        boolean rowInserted = statement.executeUpdate() > 0;
//        statement.close();
//        return rowInserted;
//    }

//    public List<Role> listAllRoles() throws SQLException {
//        List<Role> listRoles = new ArrayList<>();
//        System.out.println("Connection: " +jdbcConnection + " is connected");
//        start();
//        String sql = "SELECT * FROM role";
//        Statement statement = jdbcConnection.createStatement();
//        ResultSet resultSet = statement.executeQuery(sql);
//
//        while (resultSet.next()) {
//            int id = resultSet.getInt("rolid");
//            String rolename = resultSet.getString("rolename");
//            Role role = new Role(id,rolename);
//            listRoles.add(role);
//        }
//
//        resultSet.close();
//        statement.close();
//        return listRoles;
//
//    }

//    public boolean deleteUser(int id) throws SQLException {
//        start();
//        String sql = "DELETE FROM user where id = ?";
//        PreparedStatement statement = jdbcConnection.prepareStatement(sql);
//        statement.setInt(1, id);
//        boolean rowDeleted = statement.executeUpdate() > 0;
//        statement.close();
//        return rowDeleted;
//    }

//    public boolean updateUser(Users user) throws SQLException {
//        start();
//        String sql = "UPDATE user SET username = ?, firstname = ?, lastname = ?,dateofbirth = ?, email = ?, gender = ?," +
//                "pro_pic_path = ?, ";
//        sql += " WHERE id = ?";
//
//        PreparedStatement statement = jdbcConnection.prepareStatement(sql);
//        statement.setString(1, user.getUsername());
//        statement.setString(2, user.getFirstName());
//        statement.setString(3, user.getLastName());
//        statement.setString(4, user.getBirthDay());
//        statement.setString(5, user.getEmail());
//        statement.setString(6, user.getGender());
//        statement.setString(7, user.getImagePath());
//
//        boolean rowUpdated = statement.executeUpdate() > 0;
//        statement.close();
//
//        return rowUpdated;
//    }

    public String getAccessUrl(String userRole) throws SQLException {
        start();
        String url = null;
        String sql = "SELECT * FROM user_access WHERE role_name = ?";
        PreparedStatement statement = jdbcConnection.prepareStatement(sql);
        statement.setString(1, userRole);
        ResultSet resultSet = statement.executeQuery();

        if (resultSet.next()) {
            url = resultSet.getString("url");
        }

        resultSet.close();
        statement.close();

        return url;
    }
}
