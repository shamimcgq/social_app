package com.social.dao;

import com.social.beans.Users;
import com.social.connection.DBCon;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class UserDao {
    DBCon dbCon = new DBCon();
    Connection jdbcConnection;

    private Connection start(){
        jdbcConnection = dbCon.conectDB();
        return jdbcConnection;
    }
    private void Dbclose() throws SQLException {
        dbCon.conectDB().close();
    }

    public boolean addUser(Users users) throws SQLException {
        System.out.println("addUser Called======>>>>");
        start();
        String sql = "INSERT INTO user (username,firstname,lastname,dateofbirth,email,gender,pro_pic_path,password) VALUES (?,?,?,?,?,?,?,?)";
        PreparedStatement statement = jdbcConnection.prepareStatement(sql);
        statement.setString(1,users.getUsername());
       // System.out.println(users.getFirstName());
        statement.setString(2,users.getFirstName());
        statement.setString(3,users.getLastName());
        statement.setString(4,users.getBirthDay());
        statement.setString(5,users.getEmail());
        statement.setString(6,users.getGender());
        statement.setString(7,users.getImagePath());
        statement.setString(8,users.getPassword());
        boolean rowInserted = statement.executeUpdate() > 0;
        statement.close();

        return rowInserted;
    }

    public List<Users> listAllUsers() throws SQLException {
        List<Users> listUsers = new ArrayList<>();
        System.out.println("Connection: " +jdbcConnection + " is connected");
        start();
        String sql = "SELECT * FROM user";
        Statement statement = jdbcConnection.createStatement();
        ResultSet resultSet = statement.executeQuery(sql);

        while (resultSet.next()) {
            int id = resultSet.getInt("id");
            String username = resultSet.getString("username");
            String firstname = resultSet.getString("firstname");
            String lastname = resultSet.getString("lastname");
            String dateofbirth = resultSet.getString("dateofbirth");
            String email = resultSet.getString("email");
            String gender = resultSet.getString("gender");
            String proPicPath = resultSet.getString("pro_pic_path");

            Users users = new Users(id,username,firstname,lastname,dateofbirth,email,gender,proPicPath);
            listUsers.add(users);
        }

        resultSet.close();
        statement.close();
        return listUsers;

    }

    public boolean deleteUser(int id) throws SQLException {
        start();
        String sql = "DELETE FROM user where id = ?";
        PreparedStatement statement = jdbcConnection.prepareStatement(sql);
        statement.setInt(1, id);
        boolean rowDeleted = statement.executeUpdate() > 0;
        statement.close();
        return rowDeleted;
    }

    public boolean updateUser(Users user) throws SQLException {
        start();
        String sql = "UPDATE user SET username = ?, firstname = ?, lastname = ?, dateofbirth = ?, email = ?, gender = ?," +
                "pro_pic_path = ?, password=?";
        sql += " WHERE id = ?";

        PreparedStatement statement = jdbcConnection.prepareStatement(sql);
        statement.setString(1, user.getUsername());
        statement.setString(2, user.getFirstName());
        statement.setString(3, user.getLastName());
        statement.setString(4, user.getBirthDay());
        statement.setString(5, user.getEmail());
        statement.setString(6, user.getGender());
        statement.setString(7, user.getImagePath());
        statement.setString(8, user.getPassword());
        statement.setInt(9, user.getId());

        boolean rowUpdated = statement.executeUpdate() > 0;
        statement.close();

        return rowUpdated;
    }

    public Users getUser(int id) throws SQLException {
        start();
        Users user = null;
        String sql = "SELECT * FROM user WHERE id = ?";
        PreparedStatement statement = jdbcConnection.prepareStatement(sql);
        statement.setInt(1, id);
        ResultSet resultSet = statement.executeQuery();

        if (resultSet.next()) {
            String username = resultSet.getString("username");
            String firstname = resultSet.getString("firstname");
            String lastname = resultSet.getString("lastname");
            String dateofbirth = resultSet.getString("dateofbirth");
            String email = resultSet.getString("email");
            String gender = resultSet.getString("gender");
            String proPicPath = resultSet.getString("pro_pic_path");
            String password = resultSet.getString("password");

            user = new Users(id,username,firstname,lastname,dateofbirth,email,gender,proPicPath,password);
            System.out.println(user.getFirstName());
        }

        resultSet.close();
        statement.close();

        return user;
    }
    public Users getUser(String username) throws SQLException {
        start();
        Users user = null;
        String sql = "SELECT * FROM user WHERE username = ?";
        PreparedStatement statement = jdbcConnection.prepareStatement(sql);
        statement.setString(1, username);
        ResultSet resultSet = statement.executeQuery();

        if (resultSet.next()) {
            String firstname = resultSet.getString("firstname");
            String lastname = resultSet.getString("lastname");
            String dateofbirth = resultSet.getString("dateofbirth");
            String email = resultSet.getString("email");
            String gender = resultSet.getString("gender");
            String proPicPath = resultSet.getString("pro_pic_path");
            String password = resultSet.getString("password");

            user = new Users(username,firstname,lastname,dateofbirth,email,gender,proPicPath,password);

        }

        resultSet.close();
        statement.close();

        return user;
    }
    public List<Users> NotActivUsers() throws SQLException {
        List<Users> listUsers = new ArrayList<>();
        start();
        String sql = "SELECT *" +
                "FROM user " +
                "WHERE NOT EXISTS (" +
                "    SELECT * " +
                "    FROM role_based_user " +
                "    WHERE role_based_user.username = user.username" +
                ")";
        Statement statement = jdbcConnection.createStatement();
        ResultSet resultSet = statement.executeQuery(sql);

        while (resultSet.next()) {
            int id = resultSet.getInt("id");
            String username = resultSet.getString("username");
            String firstname = resultSet.getString("firstname");
            String lastname = resultSet.getString("lastname");
            String dateofbirth = resultSet.getString("dateofbirth");
            String email = resultSet.getString("email");
            String gender = resultSet.getString("gender");
            String proPicPath = resultSet.getString("pro_pic_path");

            Users users = new Users(id,username,firstname,lastname,dateofbirth,email,gender,proPicPath);
            listUsers.add(users);
        }

        resultSet.close();
        statement.close();
        return listUsers;

    }

}
