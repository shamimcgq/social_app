package com.social.dao;

import com.social.beans.Role;
import com.social.beans.SearchResult;
import com.social.beans.Users;
import com.social.connection.DBCon;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class TestCon {


    public static void main(String[]args) throws SQLException {
        DBCon dbCon = new DBCon();
        System.out.println(dbCon.conectDB());
        UserDao userDao = new UserDao();
        RoleDao roleDao = new RoleDao();
        searchDao srcdao = new searchDao();
//        List<SearchResult> usersList =srcdao.searchResult("Mirpur") ;
//        for(SearchResult users:usersList){
//            System.out.println(users.getUsername());
//            System.out.println(users.getCity());
//        }
        List<Users> usersList1 = userDao.NotActivUsers();
        for (Users users:usersList1){
            System.out.println(users.getUsername());
        }


//
//        Users user =null;
//        user = userDao.getUser(7);
//        System.out.println("user " + user.getFirstName()+" fetched");
//        userDao.deleteUser(7);


    }


}
