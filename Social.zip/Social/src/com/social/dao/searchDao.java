package com.social.dao;

import com.social.beans.SearchResult;
import com.social.beans.Users;
import com.social.connection.DBCon;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class searchDao {
    DBCon dbCon = new DBCon();
    Connection jdbcConnection;

    private Connection start(){
        jdbcConnection = dbCon.conectDB();
        return jdbcConnection;
    }
    private void Dbclose() throws SQLException {
        dbCon.conectDB().close();
    }
    public List<SearchResult> searchResult(String searchKey) throws SQLException {
        List<SearchResult> listUsers = new ArrayList<>();
        start();
        String sql = "SELECT user.id,username,firstname,lastname,pro_pic_path,city,school FROM user " +
                "join user_address on user.username=user_address.user_username " +
                "join usereducation on user.username = usereducation.user_username where firstname like '"+searchKey+"%' or city like '"+searchKey+"%' or " +
                "school  like '"+searchKey+"%'";
        Statement statement = jdbcConnection.prepareStatement(sql);
        ResultSet resultSet = statement.executeQuery(sql);
        while (resultSet.next()) {
            int id = resultSet.getInt("id");
            String username = resultSet.getString("username");
            String firstname = resultSet.getString("firstname");
            String lastname = resultSet.getString("lastName");
            String city = resultSet.getString("city");
            String school = resultSet.getString("school");
            String imgPth = resultSet.getString("pro_pic_path");

            SearchResult users = new SearchResult(id,username,firstname,lastname,school,city,imgPth);
            listUsers.add(users);
        }

        resultSet.close();
        statement.close();
        return listUsers;

    }

}
