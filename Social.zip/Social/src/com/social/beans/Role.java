package com.social.beans;

public class Role {
    int id;
    String rolename;

    public Role(int id,String rolename) {
        this.rolename = rolename;
        this.id = id;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getRolename() {
        return rolename;
    }

    public void setRolename(String rolename) {
        this.rolename = rolename;
    }
}
