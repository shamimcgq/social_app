package com.social.dao;

import com.social.beans.Address;
import com.social.beans.Education;
import com.social.beans.Users;
import com.social.connection.DBCon;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class AddressDao {
    DBCon dbCon = new DBCon();
    Connection jdbcConnection;

    private Connection start(){
        jdbcConnection = dbCon.conectDB();
        return jdbcConnection;
    }
    private void Dbclose() throws SQLException {
        dbCon.conectDB().close();
    }

    public boolean addAdress(Address adress) throws SQLException {
        start();
        String sql = "INSERT INTO user_address (street,city,state,country,user_username) VALUES (?,?,?,?,?)";
        PreparedStatement statement = jdbcConnection.prepareStatement(sql);
        statement.setString(1,adress.getStreet());
        statement.setString(2,adress.getCity());
        statement.setString(3,adress.getState());
        statement.setString(4,adress.getCountry());
        statement.setString(5,adress.getUsername());
        boolean rowInserted = statement.executeUpdate() > 0;
        statement.close();
        return rowInserted;
    }

    public List<Users> listAllUsers() throws SQLException {
        List<Users> listUsers = new ArrayList<>();
        System.out.println("Connection: " +jdbcConnection + " is connected");
        start();
        String sql = "SELECT * FROM user";
        Statement statement = jdbcConnection.createStatement();
        ResultSet resultSet = statement.executeQuery(sql);

        while (resultSet.next()) {
            int id = resultSet.getInt("id");
            String username = resultSet.getString("username");
            String firstname = resultSet.getString("firstname");
            String lastname = resultSet.getString("lastname");
            String dateofbirth = resultSet.getString("dateofbirth");
            String email = resultSet.getString("email");
            String gender = resultSet.getString("gender");
            String proPicPath = resultSet.getString("pro_pic_path");

            Users users = new Users(id,username,firstname,lastname,dateofbirth,email,gender,proPicPath);
            listUsers.add(users);
        }

        resultSet.close();
        statement.close();
        return listUsers;

    }

    public boolean deleteUser(int id) throws SQLException {
        start();
        String sql = "DELETE FROM user where id = ?";
        PreparedStatement statement = jdbcConnection.prepareStatement(sql);
        statement.setInt(1, id);
        boolean rowDeleted = statement.executeUpdate() > 0;
        statement.close();
        return rowDeleted;
    }

    public boolean updateUser(Users user) throws SQLException {
        start();
        String sql = "UPDATE user SET username = ?, firstname = ?, lastname = ?,dateofbirth = ?, email = ?, gender = ?," +
                "pro_pic_path = ?, ";
        sql += " WHERE id = ?";

        PreparedStatement statement = jdbcConnection.prepareStatement(sql);
        statement.setString(1, user.getUsername());
        statement.setString(2, user.getFirstName());
        statement.setString(3, user.getLastName());
        statement.setString(4, user.getBirthDay());
        statement.setString(5, user.getEmail());
        statement.setString(6, user.getGender());
        statement.setString(7, user.getImagePath());

        boolean rowUpdated = statement.executeUpdate() > 0;
        statement.close();

        return rowUpdated;
    }

    public Users getUser(int id) throws SQLException {
        start();
        Users user = null;
        String sql = "SELECT * FROM user WHERE id = ?";
        PreparedStatement statement = jdbcConnection.prepareStatement(sql);
        statement.setInt(1, id);
        ResultSet resultSet = statement.executeQuery();

        if (resultSet.next()) {
            String username = resultSet.getString("username");
            String firstname = resultSet.getString("firstname");
            String lastname = resultSet.getString("lastname");
            String dateofbirth = resultSet.getString("dateofbirth");
            String email = resultSet.getString("email");
            String gender = resultSet.getString("gender");
            String proPicPath = resultSet.getString("pro_pic_path");
            String password = resultSet.getString("password");

            user = new Users(username,firstname,lastname,dateofbirth,email,gender,proPicPath,password);
            System.out.println(user.getFirstName());
        }

        resultSet.close();
        statement.close();

        return user;
    }
    public Address getAddress(String username) throws SQLException {
        start();
        Address address = null;
        String sql = "SELECT * FROM user_address WHERE user_username =?";
        PreparedStatement statement = jdbcConnection.prepareStatement(sql);
        statement.setString(1, username);

        ResultSet resultSet = statement.executeQuery();

        if (resultSet.next()) {
            String street = resultSet.getString("street");
            String city = resultSet.getString("city");
            String state = resultSet.getString("state");
            String country = resultSet.getString("country");
            address = new Address(street,city,state,country,username);

        }

        resultSet.close();
        statement.close();

        return address;
    }
}
