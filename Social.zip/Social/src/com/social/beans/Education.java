package com.social.beans;

public class Education {
    int id;
    String username;
    String school;
    String degree;

    public Education(int id, String username, String school, String degree) {
        this.id = id;
        this.username = username;
        this.school = school;
        this.degree = degree;
    }
    public Education( String username, String school, String degree) {
        this.id = id;
        this.username = username;
        this.school = school;
        this.degree = degree;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getSchool() {
        return school;
    }

    public void setSchool(String school) {
        this.school = school;
    }

    public String getDegree() {
        return degree;
    }

    public void setDegree(String degree) {
        this.degree = degree;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }
}
