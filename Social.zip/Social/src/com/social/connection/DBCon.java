package com.social.connection;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBCon {
    // database connection settings
    private String dbURL = "jdbc:mysql://localhost:3306/cpen410";
    private String dbUser = "root";
    private String dbPass = "12345";
    public Connection conectDB(){
        Connection con = null;

            try {
                Class.forName("com.mysql.jdbc.Driver");
                con = DriverManager.getConnection(dbURL,dbUser,dbPass);
            } catch (SQLException | ClassNotFoundException throwables) {
                throwables.printStackTrace();
            }
           return con;
    }


}
