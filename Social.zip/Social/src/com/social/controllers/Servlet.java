package com.social.controllers;

import com.social.beans.*;
import com.social.dao.*;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.util.List;

@WebServlet(name = "Servlet")
public class Servlet extends HttpServlet {
    UserDao userDao = new UserDao();
    RoleDao roleDao = new RoleDao();
    EducationDao educationDao = new EducationDao();
    AddressDao addressDao = new AddressDao();
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
            doGet(request,response);
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        System.out.println("Servlet is called");
        String action = request.getServletPath();
        try {
            switch (action) {
                case "/new":
                    showNewForm(request, response);
                    break;
                case "/insert":
                    insertUser(request, response);
                    break;
                case "/delete":
                    deleteUser(request, response);
                    break;
                case "/edit":
                    showEditForm(request, response);
                    break;
                case "/update":
                    updateUser(request, response);
                    break;
                case "/allusers":
                    listUsers(request, response);
                    break;
                case "/access":
                    userAccess(request, response);
                    break;
                case "/setrole":
                    setRole(request,response);
                    break;
                case "/userlogin":
                    userlogin(request,response);
                    break;
                case "/userpage":
                    userpage(request,response);
                    break;
                case "/login":
                    login(request, response);
                    break;
                case "/logout":
                    logout(request, response);
                    break;
                case "/addedu":
                    addEdu(request, response);
                    break;
                case "/addaddress":
                    addAddress(request,response);
                    break;
                case "/searchfriend":
                    searchFriend(request,response);
                    break;
                default:
                    login(request, response);
                    break;
            }
        } catch (SQLException ex) {
            throw new ServletException(ex);
        }
    }
    private void login(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        RequestDispatcher dispatcher = request.getRequestDispatcher("login.jsp");
        dispatcher.forward(request, response);
    }

    private void listUsers(HttpServletRequest request, HttpServletResponse response)
            throws SQLException, IOException, ServletException {
        //List<Users> listUser = userDao.listAllUsers();
        List<Users> listUser = roleDao.getRoleBasedUsers();
        List<Users> inactiveUsers = userDao.NotActivUsers();
        for (Users users:listUser){
            System.out.println(users.getId());
        }
        request.setAttribute("UsersList", listUser);
        request.setAttribute("inactiveUsers",inactiveUsers);
        RequestDispatcher dispatcher = request.getRequestDispatcher("UserList.jsp");
        dispatcher.forward(request, response);
    }

    private void showNewForm(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        RequestDispatcher dispatcher = request.getRequestDispatcher("RegForm.jsp");
        dispatcher.forward(request, response);
    }

    private void showEditForm(HttpServletRequest request, HttpServletResponse response)
            throws SQLException, ServletException, IOException {
        int id = Integer.parseInt(request.getParameter("id"));
        Users userById = userDao.getUser(id);
        RequestDispatcher dispatcher = request.getRequestDispatcher("updateForm.jsp");
        request.setAttribute("user", userById);
        dispatcher.forward(request, response);

    }

    private void insertUser(HttpServletRequest request, HttpServletResponse response)
            throws SQLException, IOException {

        String username = request.getParameter("username");
        String firstname = request.getParameter("firstname");
        String lastname = request.getParameter("lastname");
        String dateofbirth = request.getParameter("birthday");
        String gender = request.getParameter("gender");
        String email = request.getParameter("email");
        String photo = request.getParameter("photo");
        String password = request.getParameter("password");
        Users users = new Users(username,firstname,lastname,dateofbirth,email,gender,photo,password);
        userDao.addUser(users);
        System.out.println("User added successfully");
        response.sendRedirect("allusers");
    }

    private void updateUser(HttpServletRequest request, HttpServletResponse response)
            throws SQLException, IOException, ServletException {
        int id = Integer.parseInt(request.getParameter("id"));
        String username = request.getParameter("username");
        String firstname = request.getParameter("firstname");
        String lastname = request.getParameter("lastname");
        String dateofbirth = request.getParameter("dateofbirth");
        System.out.println(dateofbirth);
        String gender = request.getParameter("gender");
        String email = request.getParameter("email");
        String photo = request.getParameter("photo");
        String password = request.getParameter("password");


        Users users = new Users(id,username,firstname,lastname,dateofbirth,email,gender,photo,password);
        userDao.updateUser(users);
        RequestDispatcher dispatcher = request.getRequestDispatcher("showimg.jsp");
        request.setAttribute("success","Added/Edited Successfully");
        request.setAttribute("okay","allusers");
        dispatcher.forward(request, response);
    }

    private void deleteUser(HttpServletRequest request, HttpServletResponse response)
            throws SQLException, IOException {
        int id = Integer.parseInt(request.getParameter("id"));

        userDao.deleteUser(id);

        response.sendRedirect("allusers");

    }
    private void userAccess(HttpServletRequest request, HttpServletResponse response) throws SQLException, ServletException, IOException {
        int id = Integer.parseInt(request.getParameter("id"));
        Users userById = userDao.getUser(id);
        RoleDao roleDao = new RoleDao();
        List<Role> roles = roleDao.listAllRoles();
        RequestDispatcher dispatcher = request.getRequestDispatcher("roles.jsp");
        request.setAttribute("user", userById);
        request.setAttribute("rolelist",roles);
        dispatcher.forward(request, response);
    }

    private void setRole(HttpServletRequest request, HttpServletResponse response) throws SQLException, IOException {

        String rolename = request.getParameter("rolename");
        String username = request.getParameter("username");
        Roles role = new Roles(rolename,username);
        roleDao.addRole(role);
        response.sendRedirect("allusers");
    }

    private void userlogin(HttpServletRequest request, HttpServletResponse response) throws SQLException, IOException, ServletException {
        response.setContentType("text/html");
        PrintWriter out=response.getWriter();
        String username = request.getParameter("username");
        String password = request.getParameter("password");

        Users user = userDao.getUser(username);

        //Getting user education information
        Education education = educationDao.getEdu(username);

        //Getting user address
        Address address = addressDao.getAddress(username);


        if(username.equals(user.getUsername()) && password.equals(user.getPassword())){
            // To get the role name of this user
            Roles role = roleDao.getRole(username);

            String rolefortuser = role.getRoleName();

            //To get the pages permited to this user
            AccessDao accessDao = new AccessDao();
            HttpSession session = request.getSession();
            session.setMaxInactiveInterval(1*60);
            String url = accessDao.getAccessUrl(rolefortuser);
//            System.out.println("user is:" + user.getFirstName());
//            System.out.println("user is:" + rolefortuser);
//            System.out.println("user is:" + url);

            if (rolefortuser.equals("Admin")) {

                //Setting url as sessionattribute since admin and users have different url
                session.setAttribute("admin", user.getFirstName());
                response.sendRedirect(url);
            } else if (rolefortuser.equals("User")){

                //request.setAttribute("userallinfo",user);
                //Setting url as sessionattribute since admin and users have different url
                session.setAttribute("user", user);
                session.setAttribute("edu",education);
                session.setAttribute("address",address);
                response.sendRedirect(url);

            } else {
                out.println("User role has not been set");
                request.getRequestDispatcher("login.jsp").include(request,response);
            }

        }
        else {
            out.println("Sorry! Wrong Credential");
            request.getRequestDispatcher("login.jsp").include(request,response);
        }
    }

    private void userpage(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        RequestDispatcher dispatcher = request.getRequestDispatcher("userpage.jsp");
        dispatcher.forward(request, response);
    }

    private void logout(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
        response.setContentType("text/html");
        PrintWriter out=response.getWriter();
        HttpSession session=request.getSession();
        session.invalidate();

        out.print("You are successfully logged out!");
        request.getRequestDispatcher("login.jsp").include(request,response);
        out.close();
    }

    private void addEdu(HttpServletRequest request, HttpServletResponse response) throws SQLException, IOException, ServletException {
        response.setContentType("text/html");
        PrintWriter out=response.getWriter();
        String username = request.getParameter("username");
        String school = request.getParameter("school");
        String degree = request.getParameter("degree");
        Education edu = new Education(username,school,degree);
        educationDao.addEducation(edu);
        RequestDispatcher dispatcher = request.getRequestDispatcher("showimg.jsp");
        request.setAttribute("success","Added Successfully");
        request.setAttribute("okay","userpage");
        dispatcher.forward(request, response);
    }

    private void getEdu(String username,HttpServletRequest request, HttpServletResponse response) throws SQLException, ServletException, IOException {
        Education educationByUsername = educationDao.getEdu(username);
        RequestDispatcher dispatcher = request.getRequestDispatcher("userpage.jsp");
        request.setAttribute("education", educationByUsername);
        dispatcher.forward(request, response);

    }

    private void addAddress(HttpServletRequest request, HttpServletResponse response)
            throws SQLException, IOException, ServletException {

        String username = request.getParameter("username");
        String street = request.getParameter("street");
        String city = request.getParameter("city");
        String state = request.getParameter("state");
        String country = request.getParameter("country");

        Address address = new Address(street,city,state,country,username);
        addressDao.addAdress(address);
        RequestDispatcher dispatcher = request.getRequestDispatcher("showimg.jsp");
        request.setAttribute("success","Added Successfully");
        dispatcher.forward(request, response);
    }

    private void searchFriend(HttpServletRequest request, HttpServletResponse response) throws SQLException, ServletException, IOException {
        String searchkey = request.getParameter("searchkey");
        searchDao searchDao = new searchDao();
        List <SearchResult> searcList = searchDao.searchResult(searchkey);
        RequestDispatcher dispatcher = request.getRequestDispatcher("showsearch.jsp");
        if(searcList.size()!=0) {
            request.setAttribute("searchResul", searcList);
        }
        else {
            request.setAttribute("searchResult", "Not matched");
        }
        dispatcher.forward(request, response);
    }

}
