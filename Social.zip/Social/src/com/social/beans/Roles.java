package com.social.beans;

public class Roles {
    int roleID;
    String roleName;
    String username;

    public Roles(String roleName, String username) {
        this.roleID = roleID;
        this.roleName = roleName;
        this.username = username;
    }

    public Roles(String roleName) {
        this.roleName = roleName;
    }

    public int getRoleID() {
        return roleID;
    }

    public void setRoleID(int roleID) {
        this.roleID = roleID;
    }

    public String getRoleName() {
        return roleName;
    }

    public void setRoleName(String roleName) {
        this.roleName = roleName;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }
}
